export interface SubCategoryVM {
  CategoryId: number;
  SubCategoryId: number;
  Name: string;
  IconName: string;
  TotalDirectory: number;
  SlugName:string;
}
