import { CategoryVM } from './category-master-vm';
import { SubCategoryVM } from './sub-category-master-vm';

export interface CategorySubCategoryVM {
  categoryVM: CategoryVM;
  subCategoryVM: SubCategoryVM;
}
