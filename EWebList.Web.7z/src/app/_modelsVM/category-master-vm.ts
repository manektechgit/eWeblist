export interface CategoryVM {
  CategoryId: number;
  Name: string;
  IconName: string;
  TotalDirectory: number;
  SlugName: string;
}
