export interface ContactUsModel {
  ContactId: number;
  SubjectId: number;
  Name: string;
  Email: string;
  Link: string;
  Message: string;
}
