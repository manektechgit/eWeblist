export interface LogModel {
  LogTime: Date;
  LogText: string;
}
