export class FileToUpload {
  fileName: string;
  fileSize: string;
  fileType: string;
  fileAsBase64: string;
}
