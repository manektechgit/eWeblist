export interface LoaderState {
  show: boolean;
}
