export class UserRememberData {
  Email: string;
  Password: string;
}
