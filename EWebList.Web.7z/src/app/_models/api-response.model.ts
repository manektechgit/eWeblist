export interface ApiResponseModel {
  StatusCode: number;
  Message: string;
  Result: any;
}
