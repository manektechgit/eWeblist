export interface DirectoryClickModel {
  Id?: number;
  DirectoryId: number;
  ClickDate?: Date;
  UserId?: number;
}
