export interface CountryCode {
  CountryCode: string;
  Name: string;
  AlphaCode: string;
  Active?: boolean;
}
