export class DirectoryPlanDetailModel {
  PlanId?: number;
  DirectoryId?: number;
  UserId?: number;
  IsPremimun: boolean;
  StartDate?: Date;
  EndDate?: Date;
  PaypalResponse: string;
}


