import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-login-user-footer',
  templateUrl: './login-user-footer.component.html',
  styleUrls: ['./login-user-footer.component.css']
})
export class LoginUserFooterComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
