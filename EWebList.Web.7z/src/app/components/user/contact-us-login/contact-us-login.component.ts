import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-contact-us-login',
  templateUrl: './contact-us-login.component.html',
  styleUrls: ['./contact-us-login.component.css']
})
export class ContactUsLoginComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
