export const environment = {
  production: true,
  apiUrl: 'http://www.eweblist.com/eweblistapi/api/',
  categoryImagePath: 'http://www.eweblist.com/eweblistapi/category_images/',
  subCategoryImagePath: 'http://www.eweblist.com/eweblistapi/subcategory_images/',
  directoryImagePath: 'http://www.eweblist.com/eweblistapi/directory_images/',
  userImagePath: 'http://www.eweblist.com/eweblistapi/user_images/',
  currentHostAddress: 'http://www.eweblist.com/',
  paypal_clientId: 'AZoLqhPsamNd6C6Nu4EIy74ClmLwJxG43LQan9LVi3NSqZIr3ptf5gcCX4U6dhk5Zie_VT0jBqzwipzZ'
};
// http://50.21.182.225:88/
